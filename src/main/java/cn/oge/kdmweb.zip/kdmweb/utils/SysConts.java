package cn.oge.kdmweb.utils;

public class SysConts {
	public static String DATA_APPS_XML = "data-apps.xml";
}
